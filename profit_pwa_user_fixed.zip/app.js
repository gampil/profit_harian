
const db = firebase.database();
const dataRef = db.ref('trades');

let editKey = null;

const form = document.getElementById('tradeForm');
const dateEl = document.getElementById('date');
const pairEl = document.getElementById('pair');
const profitEl = document.getElementById('profit');
const tableBody = document.getElementById('table-body');

function resetForm(){
  editKey = null;
  form.reset();
}

form.addEventListener('submit', e=>{
  e.preventDefault();
  const data = {
    date: dateEl.value,
    pair: pairEl.value,
    profit: Number(profitEl.value)
  };
  if(editKey){
    dataRef.child(editKey).update(data);
  }else{
    dataRef.push(data);
  }
  resetForm();
});

dataRef.on('value', snap=>{
  tableBody.innerHTML='';
  snap.forEach(child=>{
    const d = child.val();
    const tr = document.createElement('tr');
    tr.innerHTML = `
      <td>${d.date}</td>
      <td>${d.pair}</td>
      <td>${d.profit}</td>
      <td>
        <button onclick="editData('${child.key}','${d.date}','${d.pair}',${d.profit})">Edit</button>
        <button onclick="deleteData('${child.key}')">Hapus</button>
      </td>`;
    tableBody.appendChild(tr);
  });
});

window.editData = (key,date,pair,profit)=>{
  editKey = key;
  dateEl.value = date;
  pairEl.value = pair;
  profitEl.value = profit;
};

window.deleteData = key=>{
  if(confirm('Hapus data ini?')){
    dataRef.child(key).remove();
  }
};
